/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment.pkg2;

/**
 *
 * @author Asad
 */
import java.util.*;

public class Main {
    public static void main(String[] args) {
        // Creating a CustomerRepositoryFacade instance
        CustomerRepository customerRepository = CustomerRepository.getInstance();
        CustomerRepositoryFacade facade = new CustomerRepositoryFacade(customerRepository);

        // Creating observers
        CustomerRepositoryObserver loggingObserver = new CustomerLoggingObserver();

        // Adding observers to the facade
        facade.addObserver(loggingObserver);

        // Setting creation strategy (could be DatabaseCustomerCreationStrategy or NullCustomerCreationStrategy)
        CustomerCreationStrategy creationStrategy = new DatabaseCustomerCreationStrategy();
        facade.setCreationStrategy(creationStrategy);

        // Creating customers
        CustomerFactory customerFactory = creationStrategy.getCustomerFactory();
        Customer customer1 = customerFactory.createCustomer("Asad Waseem", "asadwasseem44@gmail.com");
        Customer customer2 = customerFactory.createCustomer("Qazi sami", "qazisami44@gmail.com");

        // Adding customers to the repository
        facade.addCustomer(1, customer1);
        facade.addCustomer(2, customer2);

        // Updating a customer's details
        facade.updateCustomer(2, "Waseem", "updateWaseem44@gmail.com");

        // Getting a customer by ID
        Customer retrievedCustomer = facade.getCustomerById(1);
        System.out.println("Retrieved Customer: " + retrievedCustomer.getName() + " - " + retrievedCustomer.getEmail());

        // Removing observer from the facade
        facade.removeObserver(loggingObserver);
    }
}
