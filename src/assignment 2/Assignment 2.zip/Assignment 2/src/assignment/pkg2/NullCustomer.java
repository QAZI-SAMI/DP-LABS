/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment.pkg2;


// NullCustomer class
class NullCustomer implements Customer {
    private static final NullCustomer INSTANCE = new NullCustomer();

    private NullCustomer() {}

    public static NullCustomer getInstance() {
        return INSTANCE;
    }

    @Override
    public String getName() {
        return "Null Customer";
    }

    @Override
    public String getEmail() {
        return "Null Email";
    }
}
