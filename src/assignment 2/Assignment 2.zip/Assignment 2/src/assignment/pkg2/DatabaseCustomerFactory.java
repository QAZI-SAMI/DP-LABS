/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment.pkg2;

/**
 *
 * @author Asad
 */
// DatabaseCustomerFactory class
class DatabaseCustomerFactory implements CustomerFactory {
    @Override
    public Customer createCustomer(String name, String email) {
        return new DatabaseCustomer(name, email);
    }
}