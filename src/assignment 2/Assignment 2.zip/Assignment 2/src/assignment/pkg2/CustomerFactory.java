/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment.pkg2;

/**
 *
 * @author Asad
 */
// CustomerFactory interface
interface CustomerFactory {
    Customer createCustomer(String name, String email);
}
