/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment.pkg2;

/**
 *
 * @author Asad
 */
// CustomerLoggingObserver class
class CustomerLoggingObserver implements CustomerRepositoryObserver {
    @Override
    public void update(Customer changedCustomer) {
        // Logic for logging customer changes
    }
}