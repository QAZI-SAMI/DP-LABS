/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment.pkg2;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Asad
 */
// CustomerRepositoryFacade class
// CustomerRepositoryFacade class
class CustomerRepositoryFacade {
    private CustomerRepository customerRepository;
    private List<CustomerRepositoryObserver> observers;

    public CustomerRepositoryFacade(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
        this.observers = new ArrayList<>();
    }

    public Customer getCustomerById(int customerId) {
        return customerRepository.getCustomerById(customerId);
    }

    public void addObserver(CustomerRepositoryObserver observer) {
        this.observers.add(observer);
    }

    public void removeObserver(CustomerRepositoryObserver observer) {
        this.observers.remove(observer);
    }

    public void addCustomer(int customerId, Customer customer) {
        customerRepository.addCustomer(customerId, customer);
    }

    public void setCreationStrategy(CustomerCreationStrategy creationStrategy) {
        customerRepository.setCreationStrategy(creationStrategy);
    }

    public void updateCustomer(int customerId, String name, String email) {
        Customer customer = customerRepository.getCustomerById(customerId);
        if (!(customer instanceof NullCustomer)) {
            ((DatabaseCustomer) customer).setName(name);
            ((DatabaseCustomer) customer).setEmail(email);
            customerRepository.notifyObservers(customer);
        }
    }
}
