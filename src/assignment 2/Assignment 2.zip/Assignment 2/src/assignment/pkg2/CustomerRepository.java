/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment.pkg2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Asad
 */
// CustomerRepository class
class CustomerRepository {
    private static final CustomerRepository INSTANCE = new CustomerRepository();
    private CustomerCreationStrategy creationStrategy;
    private Map<Integer, Customer> customerDatabase;
    private List<CustomerRepositoryObserver> observers;

    private CustomerRepository() {
        this.customerDatabase = new HashMap<>();
        this.observers = new ArrayList<>();
    }

    public static CustomerRepository getInstance() {
        return INSTANCE;
    }

    public Customer getCustomerById(int customerId) {
        return customerDatabase.getOrDefault(customerId, NullCustomer.getInstance());
    }

    public void addCustomer(int customerId, Customer customer) {
        customerDatabase.put(customerId, customer);
    }

    public void setCreationStrategy(CustomerCreationStrategy creationStrategy) {
        this.creationStrategy = creationStrategy;
    }

    public void addObserver(CustomerRepositoryObserver observer) {
        this.observers.add(observer);
    }

    public void removeObserver(CustomerRepositoryObserver observer) {
        this.observers.remove(observer);
    }

    public void notifyObservers(Customer changedCustomer) {
        for (CustomerRepositoryObserver observer : observers) {
            observer.update(changedCustomer);
        }
    }
}
